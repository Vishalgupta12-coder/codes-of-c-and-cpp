﻿#include <iostream>
using namespace std;
int main()
{int a,fact=1,i;
cout<<"Enter the value of a ";
cin>>a;
for(i=1;i<a;i++)
	{fact=fact*i;
	cout<<fact;
	}
	
return 0;
	}