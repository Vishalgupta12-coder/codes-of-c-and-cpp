﻿#include <iostream>
#include <cmath>
using namespace std;
int main()
{double x;
	cout<<"Enter Number : ";
	cin>>x;
double a=sqrt(x);
	cout<< "Square root of "<<x<<" is : "<<a;
	return 0;
	}
	
