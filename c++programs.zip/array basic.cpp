﻿#include <iostream>
using namespace std;
int main()
{int a[5];
   a[0]=19;
   a[1]=10;
   a[2]=8;
   a[3]=17;
   a[4]=9;
   cout<<"The value of a[0] is : "<<a[0]<<endl;
   cout<<"The value of a[1] is : "<<a[1]<<endl;
   cout<<"The value of a[2] is : "<<a[2]<<endl;
   cout<<"The value of a[3] is : "<<a[3]<<endl;
   cout<<"The value of a[4] is : "<<a[4]<<endl;
   
   return 0;
  }
 
   
