﻿#include <iostream>
using namespace std;
int main()
{
int a,b;
 cout<<"enter first number : ";
 cin>>a;
 cout<<"enter second number : ";
 cin>>b;
 int d= a*b;
 cout<<"multiplication of " << a << " and " << b << " is "<<d;
	return 0;
	}
