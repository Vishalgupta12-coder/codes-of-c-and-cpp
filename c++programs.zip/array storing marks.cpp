﻿#include <iostream>
using namespace std;
int main()
{int marks[10],i,j;
 cout<<"Enter the marks : "<< endl;
for(i=1;i<=10;i++)
      {cout<<"Enter marks of  "<< i <<" student : " ;
         cin>>marks[i];}
  cout<<"Displaying of Marks"<<endl;
         for(i=1;i<=10;i++)
        {cout<<"Marks  of "<< i <<" student : "<< marks[i]<<endl;}
     
 }
