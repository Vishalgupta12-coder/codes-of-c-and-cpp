﻿#include<iostream>
using namespace std;

int main()
{
int a,b;
 cout<<"enter first number : ";
 cin>>a;
 cout<<"enter second number : ";
 cin>>b;
 
 if(a>b)
 {
 cout<<" a = "<<a<<" is greater";}
 else
{ cout<<"b = "<<b<<" is greater";}
return 0;
}
